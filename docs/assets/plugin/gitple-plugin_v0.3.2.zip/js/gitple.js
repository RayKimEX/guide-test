
var isAllowAnonymous = function() {
  return jQuery('#allow-anonymous').is(":checked");
};

var isEnableTooltip = function() {
  return jQuery('#enable-tooltip').is(":checked");
}
// NOTE: disable toggle
// var toggleAnonymousFields = function() {
//   if (isAllowAnonymous()) {
//     jQuery('.anonymous-fields').css('display', 'table-row');
//   } else {
//     jQuery('.anonymous-fields').css('display', 'none');
//   }
// };

// var toggleEnableTooltip = function() {
//   if (isEnableTooltip()) {
//     jQuery('.gitple-tooltip').css('display', 'table');
//   } else {
//     jQuery('.gitple-tooltip').css('display', 'none');
//   }
// };

// function gitplePluginInit() {
//   toggleAnonymousFields();

//   jQuery('#allow-anonymous').click(function () {
//     toggleAnonymousFields();
//   });

//   jQuery('#enable-tooltip').click(function () {
//     toggleEnableTooltip();
//   });
// }

// if(window.attachEvent){
//   window.attachEvent('onload', gitplePluginInit);
// } else if (window.addEventListener) {
//   window.addEventListener('load', gitplePluginInit, false);
// } else {
//   window.onload = gitplePluginInit;
// }
