=== Plugin Name ===
Contributors: gitple
License: Apache 2.0
Tags: gitple, chat
Requires at least: 4.2.0
Tested up to: 4.2.4

The official WordPress plugin, built by Gitple.

== Description ==

Visit [Gitple](https://gitple.io/) 

== Installation ==

Installing Gitple on your WordPress site.
