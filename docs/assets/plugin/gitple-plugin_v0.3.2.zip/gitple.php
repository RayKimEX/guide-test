<?php
/*
Plugin Name: Gitple
Plugin URI: https://wordpress.org/plugins/gitple
Description: Official <a href="http://gitple.io/">Gitple</a> support for WordPress.
Author: Gitple
Author URI: http://gitple.io/
Version: 0.3.2
 */
class GitpleWordPressEscaper
{
  public static function escAttr($value)
  {
    if (function_exists('esc_attr')) {
      return esc_attr($value);
    } else {
      if (getenv('GITPLE_PLUGIN_TEST') == '1') {
        return $value;
      }
    }
  }
  public static function escJS($value)
  {
    if (function_exists('esc_js')) {
      return esc_js($value);
    } else {
      if (getenv('GITPLE_PLUGIN_TEST') == '1') {
        return $value;
      }
    }
  }
}
class GitpleSnippet
{
  private $snippet_settings = "";
  public function __construct($snippet_settings)
  {
    $this->snippet_settings = $snippet_settings;
  }
  public function html()
  {
    return $this->shutdown_on_logout() . $this->source();
  }
  private function shutdown_on_logout()
  {
    return <<<HTML
<script data-cfasync="false">
  jQuery(document).ready(function(){
    var logout_link = document.querySelectorAll('a[href*="wp-login.php?action=logout"]');
    if (logout_link) {
      for(var i=0; i < logout_link.length; i++) {
        logout_link[i].addEventListener( "click", function() {
          if (Gitple) Gitple('shutdown');
        });
      }
    }
  });
</script>

HTML;
  }
  private function source()
  {
    $app_config_json = $this->snippet_settings->appConfigJson();
    $user_config_json = $this->snippet_settings->userConfigJson();
    // $app_id = $this->snippet_settings->appId();
    return <<<HTML
<script data-cfasync="false">
window.GitpleConfig = $app_config_json;
!function(){function e(){function e(){var e=t.contentDocument,a=e.createElement("script");a.type="text/javascript",a.async=!0,a.src=window[n]&&window[n].url?window[n].url+"/inapp-web/gitple-loader.js":"https://app.gitple.io/inapp-web/gitple-loader.js",a.charset="UTF-8",e.head&&e.head.appendChild(a)}var t=document.getElementById(a);t||((t=document.createElement("iframe")).id=a,t.style.display="none",t.style.width="0",t.style.height="0",t.addEventListener?t.addEventListener("load",e,!1):t.attachEvent?t.attachEvent("onload",e):t.onload=e,document.body.appendChild(t))}var t=window,n="GitpleConfig",a="gitple-loader-frame";if(!window.Gitple){document;var i=function(){i.exec&&i.exec(arguments)};i.q=[],i.exec=function(e){i.processApi?i.processApi.apply(void 0,e):i.q&&i.q.push(e)},window.Gitple=i,t.attachEvent?t.attachEvent("onload",e):t.addEventListener("load",e,!1)}}();
if (window.Gitple) { window.Gitple('boot', $user_config_json); }
</script>
HTML;
  }
}

class GitpleSnippetSettings
{
  private $app_config = array();
  private $user_config = array();
  private $wordpress_user = NULL;
  public function __construct($app_config, $wordpress_user = NULL, $constants = array('ICL_LANGUAGE_CODE' => 'language_override'))
  {
    $this->app_config = $this->validateRawData($app_config);
    $this->wordpress_user = $wordpress_user;
    $this->constants = $constants;
  }
  public function appConfigJson()
  {
    return json_encode($this->getAppConfig());
  }
  public function userConfigJson()
  {
    return json_encode($this->getUserConfig());
  }
  public function appCode()
  {
    $app_config = $this->getAppConfig();
    return $app_config["appCode"];
  }
  private function getAppConfig()
  {
    $result = $this->mergeConstants($this->app_config);
    return $result;
  }
  private function getUserConfig()
  {
    $user = new GitpleUser($this->wordpress_user);
    $settings = $user->buildSettings();
    $result = $this->mergeConstants($settings);
    return $result;    
  }
  private function mergeConstants($settings) {
    foreach($this->constants as $key => $value) {
      if (defined($key)) {
        $const_val = GitpleWordPressEscaper::escJS(constant($key));
        $settings = array_merge($settings, array($value => $const_val));
      }
    }
    return $settings;
  }
  private function validateRawData($app_config)
  {
    if (!array_key_exists("appCode", $app_config)) {
      throw new Exception("appCode is required");
    }
    return $app_config;
  }
}

class GitpleUser
{
  private $wordpress_user = NULL;
  private $settings = array();
  public function __construct($wordpress_user)
  {
    $this->wordpress_user = $wordpress_user;
  }
  public function buildSettings()
  {
    if (empty($this->wordpress_user))
    {
      return $this->settings;
    }

    $setting_user = array();

    if (!empty($this->wordpress_user->user_login))
    {
      $setting_user["id"] = GitpleWordPressEscaper::escJS($this->wordpress_user->user_login);
    }
    if (!empty($this->wordpress_user->user_email))
    {
      $setting_user["email"] = GitpleWordPressEscaper::escJS($this->wordpress_user->user_email);
    }
    if (!empty($this->wordpress_user->display_name))
    {
      $setting_user["name"] = GitpleWordPressEscaper::escJS($this->wordpress_user->display_name);
    }

    // TODO: Add wordpress ID 
    // echo 'Username: ' . $current_user->user_login . '<br />';
    // echo 'User email: ' . $current_user->user_email . '<br />';
    // echo 'User first name: ' . $current_user->user_firstname . '<br />';
    // echo 'User last name: ' . $current_user->user_lastname . '<br />';
    // echo 'User display name: ' . $current_user->display_name . '<br />';
    // echo 'User ID: ' . $current_user->ID . '<br />';

    if (!empty($setting_user)) {
      $this->settings = $setting_user;
    }

    return $this->settings;
  }
}

class GitpleSettingsPage
{
  private $options;

  public function __construct()
  {
    add_action( 'admin_menu', array( $this, 'add_plugin_page' ) );
    add_action( 'admin_enqueue_scripts', array( $this, 'admin_enqueue' ) );
    add_action( 'admin_init', array( $this, 'page_init' ) );
  }

  public function add_plugin_page()
  {
    // This page will be under "Settings"
    add_options_page(
      'Gitple Settings',
      __('Gitple', 'gitple'),
      'manage_options',
      'gitple',
      array( $this, 'create_admin_page' )
    );
  }

  public function create_admin_page()
  {
    if (!current_user_can('manage_options'))
    {
      wp_die('You do not have sufficient permissions to access Gitple settings');
    }    
    // Set class property
    $this->options = get_option( 'gitple' );

    printf('
      <div class="wrap">
        <h1>%s</h1>
        <form method="post" action="options.php">', __('Gitple Settings', 'gitple'));
    settings_fields('gitple');
    do_settings_sections('gitple');
    submit_button();
    print '</form></div>';
  }

  public function admin_enqueue()
  {
    if($_GET["page"] != "gitple") { return; }

    wp_enqueue_style("gitple_css", plugin_dir_url(__FILE__) . "css/gitple.css");
    wp_enqueue_script("jquery");
    wp_enqueue_script("gitple_script", plugin_dir_url(__FILE__) . "js/gitple.js", array("jquery"));
  }

  /**
   * Register and add settings
   */
  public function page_init()
  {        
    register_setting('gitple', 'gitple', array($this, 'sanitize'));

    add_settings_section(
      'setting_gitple_section', // ID
      '', // Title
      array( $this, 'print_section_info' ), // Callback
      'gitple' // Page
    );  

    add_settings_field(
      'app_code', // ID
      __("App Code", 'gitple'), // Title 
      array( $this, 'app_code_callback' ), // Callback
      'gitple', // Page
      'setting_gitple_section' // Section           
    );
  }

  /**
   * Sanitize each setting field as needed
   *
   * @param array $input Contains all settings fields as array keys
   */
  public function sanitize( $input )
  {
    $new_input = array();

    if( isset( $input['app_code'] ) ) {
      $new_input['app_code'] = GitpleWordPressEscaper::escAttr( $input['app_code'] );
    }

    return $new_input;
  }

  /** 
   * Print the Section text
   */
  public function print_section_info()
  {
    $plugin_data = get_plugin_data( __FILE__ );
    $plugin_version = $plugin_data['Version'];
    printf('%s v%s</br>', __('Plugin Version', 'gitple'), $plugin_version);
    printf('<h4><a href="http://guide.gitple.io/#/wordpress-sdk" target="_blank">%s</a></h4>', __('Gitple wordpress setting guide', 'gitple'));
  }

  public function app_code_callback()
  {
    $app_code = isset( $this->options['app_code'] ) ? GitpleWordPressEscaper::escAttr( $this->options['app_code']) : '';

    printf(
      '<input type="text" class="gitple-form" id="app_code" name="gitple[app_code]" value="%s" />',
      $app_code);
  }
}

function add_gitple_snippet()
{
  $options = get_option('gitple');

  // if (is_user_logged_in() || $allow_anonymous) {
    $snippet_settings = new GitpleSnippetSettings(
      array(
        "appCode" => GitpleWordPressEscaper::escJS($options['app_code'])
      ), 
      wp_get_current_user()
    );
    $snippet = new GitpleSnippet($snippet_settings);
    echo $snippet->html();
  // }
}

function gitple_plugin_init() {
  load_plugin_textdomain( 'gitple', false, dirname( plugin_basename( __FILE__ ) )  . '/languages' );
}

if (getenv('GITPLE_PLUGIN_TEST') != '1') {
  add_action('plugins_loaded', 'gitple_plugin_init');
  add_action('wp_footer', 'add_gitple_snippet');
  if(is_admin()) {
    $my_settings_page = new GitpleSettingsPage();
  }
}

